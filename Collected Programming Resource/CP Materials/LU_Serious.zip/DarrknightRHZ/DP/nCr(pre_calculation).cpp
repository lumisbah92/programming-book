
/**

Description:
    * MX value must be defined
    * MOD must be defined
    * Computes all the nCr's from n = 1 to n = MX

**/


int nCr[MX][MX];

memset(nCr,0,sizeof nCr);
for (i=0;i<MX;i++) nCr[i][0] = nCr[i][i] = 1;
    for (i=2;i<MX;i++){
        for (j=1;j<i;j++){
            nCr[i][j] = (nCr[i-1][j] + nCr[i-1][j-1]) % MOD;
        }
    }
