/**


  ######                                                                     ######   #     #  #######
  #     #    ##    #####   #    #  #    #  #    #  #   ####   #    #  #####  #     #  #     #       #
  #     #   #  #   #    #  #   #   #   #   ##   #  #  #    #  #    #    #    #     #  #     #      #
  #     #  #    #  #    #  ####    ####    # #  #  #  #       ######    #    ######   #######     #
  #     #  ######  #####   #  #    #  #    #  # #  #  #  ###  #    #    #    #   #    #     #    #
  #     #  #    #  #   #   #   #   #   #   #   ##  #  #    #  #    #    #    #    #   #     #   #
  ######   #    #  #    #  #    #  #    #  #    #  #   ####   #    #    #    #     #  #     #  #######



**/
/*

    BismiLLAHIR RAHMANIR RAHIM
    It's not how you look or who you are underneath, it's what you do that defines you

                                ------********-------

    Status : ;
    TC: xxx/xxx;
    DOS: ;
    OJ: ;

*/

#include <bits/stdc++.h>

using namespace std;

#define test        cout<<"thiq ase boss"<<endl;
#define PB          push_back
#define PF          push_front
#define PII         pair <int,int>
#define MII         map <int,int>
#define MSI         map <string,int>
#define MIS         map <int,string>
#define MLI         map <long long int,int>
#define MIL         map <int,long long int>
typedef long long int           LL;
typedef vector <string>         VS;
typedef vector <int>            VI;
typedef vector <char>           VC;
typedef vector <LL>             VLL;

/* Functions */

int GCD (int x, int y){if (x%y==0) return y; else return (GCD(y,x%y));}

string a,b;
string s[105][105];
int dp[105][105];

int main()
{
    ios_base::sync_with_stdio(false);
    #ifdef LU_SERIOUS
        freopen("get.txt","r",stdin);
    #endif // LU_SERIOUS
    int t,cs=0,m,n,i,j;
    cin>>t;
    while (t--)
    {
        cin>>a>>b;
        m = a.size(), n = b.size();
        for (i=0;i<101;i++)
        {
            for (j=0;j<101;j++) s[i][j] = "";
        }
        for (i=1;i<=m;i++)
        {
            for (j=1;j<=n;j++)
            {
                if (a[i-1] == b[j-1])
                {
                    dp[i][j] = dp[i-1][j-1] + 1;
                    s[i][j] = s[i-1][j-1] + a[i-1];
                }
                else if (dp[i-1][j] > dp[i][j-1])
                {
                    dp[i][j] = dp[i-1][j];
                    s[i][j] = s[i-1][j];
                }
                else if (dp[i][j-1] > dp[i-1][j])
                {
                    dp[i][j] = dp[i][j-1];
                    s[i][j] = s[i][j-1];
                }
                else
                {
                    dp[i][j] = dp[i-1][j];
                    s[i][j] = min(s[i-1][j],s[i][j-1]);
                }
            }
        }
        cout<<"Case "<<++cs<<": ";
        if (dp[m][n]) cout<<s[m][n]<<endl;
        else cout<<":("<<endl;
    }
    return 0;
}


