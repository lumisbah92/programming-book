/**


  ######                                                                     ######   #     #  #######
  #     #    ##    #####   #    #  #    #  #    #  #   ####   #    #  #####  #     #  #     #       #
  #     #   #  #   #    #  #   #   #   #   ##   #  #  #    #  #    #    #    #     #  #     #      #
  #     #  #    #  #    #  ####    ####    # #  #  #  #       ######    #    ######   #######     #
  #     #  ######  #####   #  #    #  #    #  # #  #  #  ###  #    #    #    #   #    #     #    #
  #     #  #    #  #   #   #   #   #   #   #   ##  #  #    #  #    #    #    #    #   #     #   #
  ######   #    #  #    #  #    #  #    #  #    #  #   ####   #    #    #    #     #  #     #  #######



**/
/*

    BismiLLAHIR RAHMANIR RAHIM
    It's not how you look or who you are underneath, it's what you do that defines you

                                ------********-------

    Status : ;
    TC: xxx/xxx;
    DOS: ;
    OJ: ;

*/

#include <bits/stdc++.h>

using namespace std;

#define test        cout<<"thiq ase boss"<<endl;
#define PB          push_back
#define PF          push_front
#define PII         pair <int,int>
#define MII         map <int,int>
#define MSI         map <string,int>
#define MIS         map <int,string>
#define MLI         map <long long int,int>
#define MIL         map <int,long long int>
typedef long long int           LL;
typedef vector <string>         VS;
typedef vector <int>            VI;
typedef vector <char>           VC;
typedef vector <LL>             VLL;

/* Functions */

int GCD (int x, int y){if (x%y==0) return y; else return (GCD(y,x%y));}

LL n;
LL ara[35];
LL dp[35][35][2];

LL solve(LL pos, LL cnt, LL prev, int flag)
{
    if (pos == -1)
    {
        return cnt;
    }
    if (flag && dp[pos][cnt][prev] != -1) return dp[pos][cnt][prev];
    LL ret = 0,i,j,e,cn,cns;
    e = flag ? 1:ara[pos];
    for (i=0;i<=e;i++)
    {
        ret += solve(pos-1,cnt + (prev && i), i == 1, flag || (i<e));
        //if (i) ret += cns;
    }
    //ret+=prev;
    dp[pos][cnt][prev] = ret;
    //if (flag)
    //cout <<"dp["<<pos<<"]["<<prev<<"]["<<flag<<"] = "<<ret<<endl;
    //cout << "pos "<<pos<<" digit "<<ara[pos]<<" ret "<<ret<<endl;
    return ret;
}

LL toArray()
{
    LL i = 0,j;
    if (!n) return 0;
    while (n)
    {
        ara[i++] = n % 2;
        n /= 2;
    }
//    for (j=i-1;j>=0;j--) cout<<ara[j]<<" ";
//    cout<<endl;
    memset(dp,-1,sizeof dp);
    return solve(i-1,0,0,0);
}

int main()
{
    #ifdef LU_SERIOUS
        freopen("get.txt","r",stdin);
        freopen("got.txt","w+",stdout);
    #endif // LU_SERIOUS
    int t,cs=0,i,j;
    scanf("%d",&t);
    while (t--)
    {
        scanf("%lld",&n);
        LL ans = toArray();
        printf("Case %d: %lld\n",++cs,ans);
    }
    return 0;
}


