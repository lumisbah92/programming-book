#include <bits/stdc++.h>
using namespace std;

const int N = 10;

bool vis[N];
vector< int > G[N];

void dfs( int u ) {
	vis[ u ] = true;
	for( int v: G[u] ) {
		if( !vis[ v ] ) {
			dfs( v );
		}
	}
}

int main() {
	
	return 0;
}

