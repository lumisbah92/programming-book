#include <bits/stdc++.h>
using namespace std;

vector < int > G[1001];
bool vis[1001];
int lvl[1001];

void bfs(int src) {
    stack < int > s;
    memset( vis, 0, sizeof vis );
    memset( lvl, 0, sizeof lvl );
    s.push( src );
    vis[src] = true;
    while( !s.empty() ) {
        int u = s.top();
        s.pop();
        for(int v: G[u]) {
            if( !vis[v] ) {
                vis[v] = true;
                s.push( v );
                lvl[v] = lvl[u] + 1;
            }
        }
    }
}

int main() {
    int T, n, x, y, m, s;
    cin >> T;
    while( T-- && cin >> n >> m ) {
        for(int i=0; i<=n; i++) G[i].clear();
        while( m-- ) {
            cin >> x >> y;
            G[ x ].push_back( y );
            G[ y ].push_back( x );
        }
        cin >> s;
		bfs( s );
		for(int i=1; i<=n; i++) {
			if( i == s ) continue;
			if( lvl[i] ) {
				cout << lvl[i] << " ";
			} else {
				cout << -1 << " ";
			}
		}
		cout << "\n";
    }
    return 0;
}
