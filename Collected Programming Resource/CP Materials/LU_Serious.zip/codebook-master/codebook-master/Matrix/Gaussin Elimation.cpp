/**
 
GAUSSIAN ELIMINATION
 
Definition:
    ** for equation -> a1X + b1Y + c1Z = d1
    ** for equation -> a2X + b2Y + c2Z = d2
    ** for equation -> a3X + b3Y + c3Z = d3
    ** for equation -> a4X + b4Y + c4Z = d4
    we store the d in the B array
    we store the a, b, c in the A array
 
**/
 
 
 
double A[101][101], B[101];
 
void gausian(int n) {
    int i,j,k,l,e,mxIdx;
    double x,y,cns,cnt,ans,mxV;
    for (i=0,e=0; i<n; i++) {
        mxV = A[e][e];
        mxIdx = e;
        for (j=e; j<n; j++) {
            if (fabs(A[j][i]) > fabs(mxV)) {
                mxV = A[j][i];
                mxIdx = j;
            }
        }
        if (mxV < EPS) {
            e++;
            continue;
        }
        for (j=0; j<n; j++) {
            swap(A[mxIdx][j],A[e][j]);
        }
        swap(B[mxIdx],B[e]);
        for (k=0; k<n; k++) A[e][k] /= mxV;
        B[e] /= mxV;
        for (j=0; j<n; j++) {
            if (j != e) {
                x = A[j][e];
                if (fabs(x) >= EPS) {
                    for (k=0; k<n; k++) {
                        A[j][k] -= (A[e][k] * x);
                    }
                    B[j] -= (B[e] * x);
                }
            }
        }
        e++;
    }
    for (i=99; i>=0; i--) {
        for (j=99; j>=0; j--) {
            if (fabs(A[i][j]) >= EPS && i != j) {
                B[i] -= (A[i][j] * B[j]);
            }
            if (i == j && fabs(A[i][j]) >= EPS) {
                B[i] /= (A[i][j]);
            }
        }
    }
}