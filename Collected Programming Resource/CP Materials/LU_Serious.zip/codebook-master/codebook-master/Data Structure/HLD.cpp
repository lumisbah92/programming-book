 
/**
 
Heavy Light Decomposition
 
Problem (lightoj 1348 - Aladin & return journey)
 
Description:
 
    ** graph -> for storing initial graph
    ** parent -> for storing parents
    ** ChainHead -> head of each chain
    ** ChainPos -> position of each node in it's chain
    ** ChainInd -> chain number of each node
    ** chainNumber -> it's the chain count, initialy it's 0
 
Steps:
 
    1) Set chainNumber to 0
    2) Run dfs function from the root node to store subtree size
    3) Run HLD function from root to generate HLD
 
**/
 
 
 
int chainHead[MX];
int chainPos[MX];
int chainInd[MX];
int parent[MX];
int subTreeSize[MX];
int chainNumber;
vector <int> graph[MX];
vector <int> chain[MX];
 
void dfs(int x) {
    vis[x] = 1;
    int cnt,i,j;
    cnt = 1;
    for (i=0; i<graph[x].size(); i++) {
        if (!vis[graph[x][i]]) {
            dfs(graph[x][i]);
            cnt += subTreeSize[graph[x][i]];
            parent[graph[x][i]] = x;
        }
    }
    subTreeSize[x] = cnt;
}
 
void hld(int x) {
    if (chainHead[chainNumber] == -1) chainHead[chainNumber] = x;
    chain[chainNumber].PB(vi[x]);
    chainInd[x] = chainNumber;
    chainPos[x] = chain[chainNumber].size()-1;
    int ind = -1, mx = -1, i, j, u, v;
    for (i=0; i<graph[x].size(); i++) {
        u = graph[x][i];
        if (chainInd[u] == -1 && subTreeSize[u] > mx) {
            mx = subTreeSize[u];
            ind = u;
        }
    }
    if (ind != -1) {
        hld(ind);
    }
    for (i=0; i<graph[x].size(); i++) {
        u = graph[x][i];
        if (chainInd[u] == -1) {
            chainNumber++;
            hld(u);
        }
    }
}