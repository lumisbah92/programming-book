#define MAX 500001

struct trie
{
    int cand[2];
    trie()
    {
        clrall(cand,-1);
    }
};

trie tree[MAX*32+7];
ll csum;

int tot_node;

void insert_trie(int root,ll val)
{
    int i,j,k;
    int fbit;
    rvp(i,0,32)
    {
        fbit=(int) ((val>>(ll) i)&1LL);
        if(tree[root].cand[fbit]==-1)
        {
            tree[root].cand[fbit] = ++tot_node;
        }
        root = tree[root].cand[fbit];
    }
    return ;
}

int delete_trie(int root,ll val,int i)
{
    if(i==-1) return 0;
    int fbit;
    fbit=(int) ((val>>(ll) i)&1LL);
    if(tree[root].cand[fbit]==-1) return 0;
    int chld=delete_trie(tree[root].cand[fbit],val,i-1);
    if(chld==0)
    {
        tree[root].cand[fbit]=-1;
    }
    int nchld=0;
    if(tree[root].cand[fbit]!=-1) nchld++;
    if(tree[root].cand[!fbit]!=-1) nchld++;
    return nchld;
}

ll solve(int root,ll cval)
{
    ll res=0;
    int fbit,cbit;
    int i,j,k;
    rvp(i,0,32)
    {
        fbit=(int) ((cval>>(ll) i)&1LL);
        cbit=!(fbit);
        if(tree[root].cand[fbit]!=-1)
        {
            if(fbit) res|=(1LL << (ll) i);
            root=tree[root].cand[fbit];
        }
        else
        {
            if(cbit) res|=(1LL << (ll) i);
            root=tree[root].cand[cbit];
        }
    }
    return res;
}

ll max_val(ll val)
{
    int i,j,k;
    ll ret=0;
    int gbit;
    rvp(i,0,32)
    {
        gbit=(int) ((val>>(ll) i)&1LL);
        if(!gbit) ret|=(1LL << (ll) i);
    }
    return ret;
}