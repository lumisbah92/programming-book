/// for i to n
///  ( pi^(xi+1) - 1 ) / ( pi - 1 ) )

ll ans() {
    ll ret = 1, cnt, h;
    for( int i=0; i < prime.size() && prime[i]*prime[i] <= n; i++ ) {
        if( n % prime[i] == 0 ) {
            cnt = 0;
            while( n % prime[i] == 0 ) {
                n /= prime[i];
                cnt++;
            }
            cnt *= m;
            cnt++;
            h = ( ( ( big_mod( prime[i], cnt ) - 1LL + mod ) % mod ) * big_mod( prime[i] - 1LL, mod - 2LL ) ) % mod;
            ret = ( ret * h ) % mod;
//            cerr << ( big_mod( prime[i], cnt + 1 ) - 1 ) << " - " << ( powl( prime[i], cnt + 1 ) - 1 ) << "\n";
        }
    }
    if( n > 1 ) {
        h = ( ( ( big_mod( n, m + 1LL ) - 1LL + mod ) % mod ) * big_mod( n - 1LL, mod - 2LL ) ) % mod;
        ret = ( ret * h ) % mod;
    }
    return ret % mod;
}
