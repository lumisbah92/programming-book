void sievephi()
{
    mark[1] = 1;
    for(ll i = 1; i < Mx; i++)
    {
        phi[i] = i;
        if(!(i & 1)) mark[i] = 1, phi[i] /= 2;
    }
    mark[2] = 0;
 
    for(ll i = 3; i < Mx; i+=2)
    {
        if(!mark[i])
        {
            phi[i] = phi[i] - 1;
            for(ll j = 2 * i; j < Mx; j += i)
            {
                mark[j] = 1;
                phi[j] /= i;
                phi[j] *= i - 1;
            }
        }
    }
}