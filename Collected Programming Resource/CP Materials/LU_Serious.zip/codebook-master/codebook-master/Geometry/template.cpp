const double EPS = 1e-9;
const double PI = acos(-1.0);
 
/** GeometryStructures **/
 
struct g_point
{
    double x,y;
    g_point()
    {
        x = y = 0;
    }
    g_point(double _x,double _y)
    {
        x = _x; y = _y;
    }
    bool operator < (g_point other) const
    {
        if (fabs(x - other.x) > EPS)
        {
            return x < other.x;
        }
        return y < other.y;
    }
    bool operator == (g_point other) const
    {
        return ((fabs(x - other.x) < EPS) && (fabs(y - other.y)));
    }
};
 
struct g_line
{
    double a,b,c;
    g_line ()
    {
        a = b = c = 0;
    }
    g_line(double _a,double _b, double _c)
    {
        a = _a; b = _b; c = _c;
    }
};
 
struct g_vector
{
    double x,y;
    g_vector (double _x, double _y)
    {
        x = _x;
        y = _y;
    }
};
 
 
/**  Function List  **/
 
//Geometry
double DEG_to_RAD (double theta); ///converts degree to radian
double RAD_to_DEG (double theta); ///converst radian to degree
double g_dist(g_point p1, g_point p2); ///finds euclidian distance between two points
g_point g_rotate(g_point p, double theta); ///rotates point 'p' by 'theta' degrees
void g_pointsToLine (g_point p1, g_point p2, g_line &l); ///initiates line 'l'
bool g_areParallel(g_line l1, g_line l2); ///returns true if two lines are parallel
bool g_areSame(g_line l1, g_line l2); ///returns true if two lines are same or two segments (l1 and l2) are in same line
bool g_areIntersect(g_line l1, g_line l2, g_point &p); ///returns true if two lines intersect, sets the point of intersect as 'p'
g_vector g_toVec(g_point a, g_point b); ///returns a vector from point 'a' -> 'b'
g_vector g_scale(g_vector v, double s); ///returns a vector scaled or multiplied by 's'
g_point g_translate(g_point p, g_vector v); ///returns a point which is a translation of 'p'
double g_dot (g_vector a, g_vector b); ///returns dot product of two vectors
double g_cross(g_vector a, g_vector b); ///returns cross product of two vectors
double g_norm_sq(g_vector v); ///returns v.x * v.x + v.y * v.y, essential for finding distance of point to line segment and angle between points.
double g_distToLine(g_point p, g_point a, g_point b, g_point &c); ///returns shortest distance from point 'p' to line a->b, stores closest point to as 'c'
double g_distToLineSegment(g_point p, g_point a, g_point b, g_point &c); /// returns shortest distance from point 'p' to lineSegment a->b, stores closest point to as 'c'
double g_angle(g_point a, g_point o, g_point b); ///return angle <aob
bool g_ccw(g_point q, g_point p, g_point r); ///returns true if 'r' in left side of line p->q (counter clock-wise test)
bool g_cw(g_point q, g_point p, g_point r); ///returns true if 'r' in right side of line p->q (clock-wise test)
bool g_collinear (g_point q, g_point p, g_point r); ///returns true if three points are collinear;
 
int GCD (int x, int y){if (x%y==0) return y; else return (GCD(y,x%y));}
 
int main()
{
    #ifdef O_Amay_Valo_Basheni
        freopen("get.txt","r",stdin);
    #endif // O_Amay_Valo_Basheni
    g_point a(2,2),b(4,3),c(3,2);
    g_vector ab = g_toVec(a,b);
    //ab.x/=2; ab.y/=2;
    c = g_translate(c,ab);
    cout<<c.x<<" "<<c.y<<endl;
    c = g_rotate(c,360);
    cout<<c.x<<" "<<c.y<<endl;
    c = g_rotate(c,180);
    cout<<c.x<<" "<<c.y<<endl;
//    double d = DEG_to_RAD(360);
//    c = g_rotate(c,d);
//    cout<<c.x<<" "<<c.y<<endl;
    return 0;
}
 
 
 
 
/** GeometryFunctions **/
 
double DEG_to_RAD (double theta)
{
    return ((theta * PI)/180.0);
}
 
double RAD_to_DEG (double theta)
{
    return ((theta * 180.0) /PI);
}
 
double g_dist(g_point p1, g_point p2)
{
    return hypot(p1.x - p2.x, p1.y - p2.y);
}
 
g_point g_rotate(g_point p, double theta)
{
    double rad = DEG_to_RAD(theta);
    //rad = theta;
    //rad = (theta *(180.0/PI));
    return g_point (p.x * cos(rad) - p.y * sin(rad), p.x * sin(rad) + p.y * cos (rad));
}
 
void g_pointsToLine (g_point p1, g_point p2, g_line &l)
{
    if (fabs(p1.x - p2.x) < EPS)
    {
        l.a = 1.0; l.b = 0.0; l.c = -p1.x;
    }
    else
    {
        l.b = 1.0;
        l.a = -(double) (p1.y - p2.y)/ (p1.x - p2.x);
        l.c = -(double) (l.a * p1.x) - p1.y;
    }
}
 
bool g_areParallel(g_line l1, g_line l2)
{
    return ((fabs (l1.a - l2.a) < EPS) && (fabs(l1.b - l2.b) < EPS));
}
 
bool g_areSame(g_line l1, g_line l2)
{
    return ((g_areParallel(l1,l2)) && (fabs(l1.c - l2.c) < EPS));
}
 
bool g_areIntersect(g_line l1, g_line l2, g_point &p)
{
    if (g_areParallel(l1,l2)) return false;
    p.x = (l2.b * l1.c - l1.b * l2.c) / (l2.a * l1.b - l1.a * l2.b);
    if (fabs(l1.b) > EPS)
        p.y = -(l1.a * p.x + l1.c);
    else
        p.y = -(l2.a * p.x + l2.c);
    return true;
}
 
g_vector g_toVec(g_point a, g_point b)
{
    return g_vector (b.x - a.x, b.y - a.y);
}
 
g_vector g_scale(g_vector v, double s)
{
    return g_vector(v.x * s, v.y * s);
}
 
g_point g_translate(g_point p, g_vector v)
{
    return g_point(p.x + v.x, p.y + v.y);
}
 
double g_dot(g_vector a, g_vector b)
{
    return (a.x * b.x + a.y * b.y);
}
 
double g_cross(g_vector a, g_vector b)
{
    return (a.x * b.y - a.y * b.x);
}
 
double g_norm_sq(g_vector v)
{
    return v.x * v.x + v.y * v.y;
}
 
double g_distToLine(g_point p, g_point a, g_point b, g_point &c)
{
    g_vector ap = g_toVec(a,p);
    g_vector ab = g_toVec(a,b);
    double u = g_dot(ap,ab) / g_norm_sq(ab);
    c = g_translate(a,g_scale(ab,u));
    return g_dist (p,c);
}
 
double g_distToLineSegment(g_point p, g_point a, g_point b, g_point &c)
{
    g_vector ap = g_toVec(a,p);
    g_vector ab = g_toVec(a,b);
    double u = g_dot(ap,ab) / g_norm_sq(ab);
    if (u < 0.0)
    {
        return g_dist(p,a);
    }
    if (u > 1.0)
    {
        return g_dist(p,b);
    }
    c = g_translate(a,g_scale(ab,u));
    return g_dist(p,c);
}
 
double g_angle(g_point a, g_point o, g_point b)
{
    g_vector oa = g_toVec(o,a);
    g_vector ob = g_toVec(o,b);
    return acos (g_dot(oa,ob) / sqrt(g_norm_sq(oa) * g_norm_sq(ob)));
}
 
bool g_ccw(g_point q, g_point p, g_point r)
{
    return g_cross (g_toVec(p,q),g_toVec(p,r)) > 0;
}
 
bool g_cw(g_point q, g_point p, g_point r)
{
    return g_cross (g_toVec(p,q),g_toVec(p,r)) < 0;
}
 
bool g_collinear (g_point q, g_point p, g_point r)
{
    return fabs(g_cross(g_toVec(p,q),g_toVec(p,r))) < EPS;
}