/**
 
CONVEX HULL
 
Definition:
    ** Uses vp as an inner temporary vector to store hull
    ** Uses hull vector to store the hull
 
**/
 
 
vector <g_point> vp;
vector <g_point> hull;
 
g_point pivot;
 
bool cmp(g_point p, g_point q)
{
    if (g_collinear(p,pivot,q))
    {
        return g_dist(pivot,p) < g_dist(pivot,q);
    }
    double dx1,dx2,dy1,dy2;
    dx1 = p.x - pivot.x;
    dx2 = q.x - pivot.x;
    dy1 = p.y - pivot.y;
    dy2 = q.y - pivot.y;
    return atan2(dy1, dx1) < atan2(dy2, dx2);  // atan2 function is used for double
}
 
void buildhull() // works if n>=3
{
    int i,j,id;
    double x,y;
    g_point p,mx;
    hull.clear();
    mx = vp[0];
    id = 0;
    for (i=0;i<vp.size();i++)
    {
        p = vp[i];
        if (p.y < mx.y || (p.y == mx.y && p.x > mx.x))
        {
            mx = p;
            id = i;
        }
    }
    swap(vp[0],vp[id]);
    pivot = mx;
    sort(vp.begin()+1,vp.end(),cmp);
    vector <g_point> stk;
    int sz = vp.size() - 1;
    stk.PB(vp[sz]);
    stk.PB(vp[0]);
    stk.PB(vp[1]);
    i = 2;
    while (i < n)
    {
        p = vp[i];
        sz = stk.size() - 1;
        if (g_ccw(stk[sz],stk[sz-1],p))
        {
            stk.PB(p);
            i++;
        }
        else
        {
            stk.pop_back();
        }
    }
    swap(hull,stk);
}
