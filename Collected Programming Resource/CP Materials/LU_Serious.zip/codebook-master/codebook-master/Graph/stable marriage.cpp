int t, n;
int ar[201][101];
int partners[101];
int fl[101];
 
bool check( int w, int m, int m1 ) {
    for( int i=0; i<n; i++ ) {
        if( ar[w][i] == m1 ) return true;
        if( ar[w][i] == m ) return false;
    }
    return true;
}
 
void stable_match() {
    memset( partners, -1, sizeof partners );
    memset( fl, 0, sizeof fl );
    int cnt = n;
    int m, w, m1;
    while( cnt ) {
        for( m=0; m<n; m++ ) if( !fl[m] ) break;
        for( int i=0; i<n && !fl[m]; i++ ) {
            w = ar[m][i];
            if( partners[w-n] == - 1 ) {
                partners[w-n] = m;
                fl[m] = 1;
                cnt--;
            } else {
                m1 = partners[w-n];
                if( !check( w, m, m1 ) ) {
                    partners[w-n] = m;
                    fl[m] = 1;
                    fl[m1] = 0;
                }
            }
        }
    }
    for( int i=0; i<n; i++ ) {
        printf( " (%d %d)", partners[i]+1, i+n+1 );
    }
    printf( "\n" );
}
 