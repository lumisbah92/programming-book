struct Edge {
    int u, v, w;
};
vector < Edge > vs;
int n, dis[205];
 
void bell() {
    dis[1] = 0;
    for(int i = 1; i < n; i++) {
        for(int j = 0; j < vs.size(); j++) {
            if( dis[ vs[j].v ] > dis[ vs[j].u ] + vs[j].w ) {
            	dis[vs[j].v] = dis[vs[j].u] + vs[j].w;
            }
        }
    }
}
