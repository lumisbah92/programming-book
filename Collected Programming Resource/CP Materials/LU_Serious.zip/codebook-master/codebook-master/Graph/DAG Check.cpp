vector < int > G[mx], tops;
bool vis[mx], bg[mx];
 
bool dfs( int u ) {
    bool ret = true;
    if( !vis[u] ) {
        vis[u] = 1;
        bg[u] = 1;
        int v;
        for( int i=0; i<G[u].size(); i++ ) {
            v = G[u][i];
            if( !vis[v] ) {
                ret &= dfs( v );
            }
            if( bg[v] ) return false;
        }
    }
    bg[u] = false;
    return true;
}
 
bool dag( int n) {
    memset( vis, 0, sizeof vis );
    memset( bg, 0, sizeof bg );
    bool ret = true;
    for( int i=1; i<=n; i++ ) {
        if( !vis[i] ) {
            ret &= dfs( i );
        }
    }
